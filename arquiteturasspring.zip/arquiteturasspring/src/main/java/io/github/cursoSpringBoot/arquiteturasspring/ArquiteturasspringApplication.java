package io.github.cursoSpringBoot.arquiteturasspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArquiteturasspringApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArquiteturasspringApplication.class, args);
	}

}
