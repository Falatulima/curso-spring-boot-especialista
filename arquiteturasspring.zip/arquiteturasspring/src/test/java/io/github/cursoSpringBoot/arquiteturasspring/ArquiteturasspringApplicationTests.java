package io.github.cursoSpringBoot.arquiteturasspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArquiteturasspringApplicationTests {

	@Test
	void contextLoads() {
	}

}
